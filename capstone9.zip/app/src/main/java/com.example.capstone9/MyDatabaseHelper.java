package com.example.capstone9;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MyDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "mydb";
    private static final int DATABASE_VERSION = 1;



    public MyDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        // 테이블 생성
        String createTableSql = "CREATE TABLE events (_id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, event TEXT)";
        sqLiteDatabase.execSQL(createTableSql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        // 테이블 업그레이드
        String dropTableSql = "DROP TABLE IF EXISTS events";
        sqLiteDatabase.execSQL(dropTableSql);
        onCreate(sqLiteDatabase);
    }


}

