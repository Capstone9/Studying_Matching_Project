package com.example.capstone9.Fragments;

import android.content.ContentValues;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.capstone9.MyDatabaseHelper;
import com.example.capstone9.R;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

public class CalendarFragment extends AppCompatActivity {

    private TextView eventTextView;
    private Button addButton;
    private CalendarView calendarView;
    private EditText eventEditText;
    private LinearLayout eventContainer;

    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
    private int selectedYear;
    private int selectedMonth;
    private int selectedDay;
    private MyDatabaseHelper db;

    private static final String PREF_YEAR = "year";
    private static final String PREF_MONTH = "month";
    private static final String PREF_DAY = "day";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cal);

        eventTextView = findViewById(R.id.event_text_view);
        addButton = findViewById(R.id.add_button);
        calendarView = findViewById(R.id.calendar_view);
        eventEditText = findViewById(R.id.event_edit_text);
        eventContainer = findViewById(R.id.event_container);

        db = new MyDatabaseHelper(this);

        restoreSelectedDate();

        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                selectedYear = year;
                selectedMonth = month;
                selectedDay = dayOfMonth;

                String selectedDateStr = dateFormat.format(new Date(selectedYear - 1900, selectedMonth, selectedDay));
                eventTextView.setText(""); // Clear the message
                Cursor cursor = getEventsForDate(selectedDateStr);
                displayEventsWithDeleteButtons(cursor);
            }
        });

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String event = eventEditText.getText().toString().trim();
                if (event.isEmpty()) {
                    Toast.makeText(CalendarFragment.this, "일정을 입력하세요", Toast.LENGTH_SHORT).show();
                    return;
                }

                Calendar selectedDate = Calendar.getInstance();
                selectedDate.set(selectedYear, selectedMonth, selectedDay);

                addEventToDatabase(event, selectedDate);

                String message = dateFormat.format(selectedDate.getTime()) + ": 일정 추가됨";
                Toast.makeText(CalendarFragment.this, message, Toast.LENGTH_SHORT).show();

                eventEditText.getText().clear();
                refreshEventsDisplay();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        calendarView.setDate(new GregorianCalendar(selectedYear, selectedMonth, selectedDay).getTimeInMillis(), false, true);

        String selectedDateStr = dateFormat.format(new Date(selectedYear - 1900, selectedMonth, selectedDay));
        Cursor cursor = getEventsForDate(selectedDateStr);
        displayEventsWithDeleteButtons(cursor);
    }

    @Override
    protected void onPause() {
        super.onPause();

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt(PREF_YEAR, selectedYear);
        editor.putInt(PREF_MONTH, selectedMonth);
        editor.putInt(PREF_DAY, selectedDay);
        editor.apply();
    }

    private void restoreSelectedDate() {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        selectedYear = preferences.getInt(PREF_YEAR, Calendar.getInstance().get(Calendar.YEAR));
        selectedMonth = preferences.getInt(PREF_MONTH, Calendar.getInstance().get(Calendar.MONTH));
        selectedDay = preferences.getInt(PREF_DAY, Calendar.getInstance().get(Calendar.DAY_OF_MONTH));
    }

    private void addEventToDatabase(String event, Calendar selectedDate) {
        SQLiteDatabase sqLiteDatabase = db.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("date", dateFormat.format(selectedDate.getTime()));
        values.put("event", event);
        sqLiteDatabase.insert("events", null, values);
        sqLiteDatabase.close();
    }

    private Cursor getEventsForDate(String date) {
        SQLiteDatabase sqLiteDatabase = db.getReadableDatabase();
        String[] projection = {"_id", "date", "event"};
        String selection = "date=?";
        String[] selectionArgs = {date};
        return sqLiteDatabase.query("events", projection, selection, selectionArgs, null, null, null);
    }

    private void deleteEvent(int eventId) {
        SQLiteDatabase sqLiteDatabase = db.getWritableDatabase();
        String selection = "_id=?";
        String[] selectionArgs = {String.valueOf(eventId)};
        int deletedRows = sqLiteDatabase.delete("events", selection, selectionArgs);
        sqLiteDatabase.close();

        if (deletedRows > 0) {
            Toast.makeText(this, "일정을 삭제하였습니다.", Toast.LENGTH_SHORT).show();
            refreshEventsDisplay();
        } else {
            Toast.makeText(this, "일정을 삭제하지 못했습니다.", Toast.LENGTH_SHORT).show();
        }
    }

    private void refreshEventsDisplay() {
        String selectedDateStr = dateFormat.format(new Date(selectedYear - 1900, selectedMonth, selectedDay));
        Cursor cursor = getEventsForDate(selectedDateStr);
        displayEventsWithDeleteButtons(cursor);

        if (cursor == null || cursor.getCount() == 0) {
            eventTextView.setText("일정이 없습니다.");
        } else {
            eventTextView.setText("");
        }
        cursor.close();
    }

    private void displayEventsWithDeleteButtons(Cursor cursor) {
        eventContainer.removeAllViews();

        if (cursor == null || cursor.getCount() == 0) {
            eventTextView.setText("일정이 없습니다.");
            return;
        }

        LayoutInflater inflater = LayoutInflater.from(this);

        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("_id"));
            String event = cursor.getString(cursor.getColumnIndexOrThrow("event"));
            String date = cursor.getString(cursor.getColumnIndexOrThrow("date"));

            View eventItemView = inflater.inflate(R.layout.event_item, eventContainer, false);
            TextView eventTextView = eventItemView.findViewById(R.id.event_text_view);
            eventTextView.setText(date + ": " + event);

            ImageButton deleteButton = eventItemView.findViewById(R.id.delete_button);
            deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    deleteEvent(id);
                }
            });

            eventContainer.addView(eventItemView);
        }

        cursor.close();
    }

    protected void onDestroy() {
        db.close();
        super.onDestroy();
    }
}
