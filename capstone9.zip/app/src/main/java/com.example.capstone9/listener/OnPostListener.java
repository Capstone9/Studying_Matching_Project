package com.example.capstone9.listener;

public interface OnPostListener {

    void onDelete();

    void onModify();
}
